"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface User {
  id: number
  name: string
  email: string
}

interface AuthStore {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
}

export const useAuth = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,

      login: async (email: string, password: string) => {
        set({ isLoading: true })

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock successful login
        const user = {
          id: 1,
          name: email.split("@")[0],
          email,
        }

        set({ user, isLoading: false })
      },

      logout: () => {
        set({ user: null })
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)
