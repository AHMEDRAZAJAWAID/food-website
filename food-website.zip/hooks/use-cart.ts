"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface CartItem {
  id: number
  name: string
  price: string
  image: string
  quantity: number
  originalPrice?: string
}

interface CartStore {
  items: CartItem[]
  totalItems: number
  totalPrice: number
  addItem: (item: Omit<CartItem, "quantity">) => void
  updateQuantity: (id: number, quantity: number) => void
  removeItem: (id: number) => void
  clearCart: () => void
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      totalItems: 0,
      totalPrice: 0,

      addItem: (item) => {
        const items = get().items
        const existingItem = items.find((i) => i.id === item.id)

        if (existingItem) {
          set((state) => ({
            items: state.items.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)),
          }))
        } else {
          set((state) => ({
            items: [...state.items, { ...item, quantity: 1 }],
          }))
        }

        // Update totals
        const newState = get()
        const totalItems = newState.items.reduce((sum, item) => sum + item.quantity, 0)
        const totalPrice = newState.items.reduce((sum, item) => {
          const price = Number.parseInt(item.price.replace("₹", ""))
          return sum + price * item.quantity
        }, 0)

        set({ totalItems, totalPrice })

        // Show success message (you can integrate with toast library)
        console.log(`${item.name} added to cart successfully!`)
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id)
          return
        }

        set((state) => ({
          items: state.items.map((item) => (item.id === id ? { ...item, quantity } : item)),
        }))

        // Update totals
        const newState = get()
        const totalItems = newState.items.reduce((sum, item) => sum + item.quantity, 0)
        const totalPrice = newState.items.reduce((sum, item) => {
          const price = Number.parseInt(item.price.replace("₹", ""))
          return sum + price * item.quantity
        }, 0)

        set({ totalItems, totalPrice })
      },

      removeItem: (id) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== id),
        }))

        // Update totals
        const newState = get()
        const totalItems = newState.items.reduce((sum, item) => sum + item.quantity, 0)
        const totalPrice = newState.items.reduce((sum, item) => {
          const price = Number.parseInt(item.price.replace("₹", ""))
          return sum + price * item.quantity
        }, 0)

        set({ totalItems, totalPrice })
      },

      clearCart: () => set({ items: [], totalItems: 0, totalPrice: 0 }),
    }),
    {
      name: "cart-storage",
    },
  ),
)
