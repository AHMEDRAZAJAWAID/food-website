"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, TrendingUp, Award, Users, Clock, Filter } from "lucide-react"
import { ImprovedFoodCard } from "@/components/improved-food-card"

interface Dish {
  id: number
  name: string
  price: string
  originalPrice?: string
  image: string
  rating: number
  time: string
  isSpicy: boolean
  discount?: string
  category: string
  description: string
  isVeg: boolean
  isPopular?: boolean
  isBestseller?: boolean
}

const allDishes: Dish[] = [
  // Main Course
  {
    id: 1,
    name: "Spicy Chicken Biryani",
    price: "₹299",
    originalPrice: "₹399",
    image: "/images/biryani.png",
    rating: 4.8,
    time: "25-30 min",
    isSpicy: true,
    discount: "25% OFF",
    category: "Main Course",
    description: "Aromatic basmati rice with tender chicken and exotic spices",
    isVeg: false,
    isPopular: true,
    isBestseller: true,
  },
  {
    id: 2,
    name: "Butter Chicken with Naan",
    price: "₹349",
    originalPrice: "₹449",
    image: "/images/butter-chicken.png",
    rating: 4.9,
    time: "20-25 min",
    isSpicy: false,
    discount: "22% OFF",
    category: "Main Course",
    description: "Creamy tomato-based curry with tender chicken pieces",
    isVeg: false,
    isPopular: true,
  },
  {
    id: 3,
    name: "Paneer Tikka Masala",
    price: "₹279",
    originalPrice: "₹349",
    image: "/images/paneer-tikka.png",
    rating: 4.7,
    time: "15-20 min",
    isSpicy: true,
    discount: "20% OFF",
    category: "Main Course",
    description: "Grilled cottage cheese in rich tomato gravy",
    isVeg: true,
    isBestseller: true,
  },
  {
    id: 4,
    name: "Mutton Rogan Josh",
    price: "₹449",
    originalPrice: "₹549",
    image: "/images/mutton-rogan.png",
    rating: 4.9,
    time: "35-40 min",
    isSpicy: true,
    discount: "18% OFF",
    category: "Main Course",
    description: "Traditional Kashmiri mutton curry with aromatic spices",
    isVeg: false,
  },
  {
    id: 5,
    name: "Dal Makhani",
    price: "₹199",
    originalPrice: "₹249",
    image: "/images/dal-makhani.png",
    rating: 4.6,
    time: "15-20 min",
    isSpicy: false,
    discount: "20% OFF",
    category: "Main Course",
    description: "Creamy black lentils slow-cooked with butter and cream",
    isVeg: true,
  },
  {
    id: 6,
    name: "Fish Curry",
    price: "₹329",
    originalPrice: "₹399",
    image: "/images/fish-curry.png",
    rating: 4.7,
    time: "25-30 min",
    isSpicy: true,
    discount: "18% OFF",
    category: "Main Course",
    description: "Fresh fish cooked in coconut milk and spices",
    isVeg: false,
  },

  // Starters
  {
    id: 7,
    name: "Chicken Tandoori",
    price: "₹399",
    originalPrice: "₹499",
    image: "/images/chicken-tandoori.png",
    rating: 4.8,
    time: "30-35 min",
    isSpicy: true,
    discount: "20% OFF",
    category: "Starters",
    description: "Clay oven grilled chicken marinated in yogurt and spices",
    isVeg: false,
    isPopular: true,
  },
  {
    id: 8,
    name: "Buffalo Chicken Wings",
    price: "₹299",
    originalPrice: "₹379",
    image: "/images/chicken-wings.png",
    rating: 4.6,
    time: "20-25 min",
    isSpicy: true,
    discount: "21% OFF",
    category: "Starters",
    description: "Crispy chicken wings tossed in spicy buffalo sauce",
    isVeg: false,
  },

  // Fast Food
  {
    id: 9,
    name: "Veg Hakka Noodles",
    price: "₹199",
    originalPrice: "₹249",
    image: "/images/hakka-noodles.png",
    rating: 4.6,
    time: "15-20 min",
    isSpicy: false,
    discount: "20% OFF",
    category: "Fast Food",
    description: "Stir-fried noodles with fresh vegetables and sauces",
    isVeg: true,
  },
  {
    id: 10,
    name: "Margherita Pizza",
    price: "₹349",
    originalPrice: "₹449",
    image: "/images/pizza-margherita.png",
    rating: 4.7,
    time: "20-25 min",
    isSpicy: false,
    discount: "22% OFF",
    category: "Fast Food",
    description: "Classic pizza with fresh mozzarella, tomatoes and basil",
    isVeg: true,
    isPopular: true,
  },
  {
    id: 11,
    name: "Chicken Deluxe Burger",
    price: "₹249",
    originalPrice: "₹319",
    image: "/images/burger-deluxe.png",
    rating: 4.5,
    time: "15-20 min",
    isSpicy: false,
    discount: "22% OFF",
    category: "Fast Food",
    description: "Juicy chicken patty with lettuce, tomato and special sauce",
    isVeg: false,
  },
  {
    id: 12,
    name: "Chicken Alfredo Pasta",
    price: "₹299",
    originalPrice: "₹379",
    image: "/images/pasta-alfredo.png",
    rating: 4.6,
    time: "18-22 min",
    isSpicy: false,
    discount: "21% OFF",
    category: "Fast Food",
    description: "Creamy pasta with grilled chicken and parmesan cheese",
    isVeg: false,
  },

  // Thali
  {
    id: 13,
    name: "Vegetarian Thali",
    price: "₹199",
    originalPrice: "₹249",
    image: "/images/veg-thali.png",
    rating: 4.8,
    time: "20-25 min",
    isSpicy: false,
    discount: "20% OFF",
    category: "Thali",
    description: "Complete meal with dal, sabzi, roti, rice, and dessert",
    isVeg: true,
    isBestseller: true,
  },

  // Desserts
  {
    id: 14,
    name: "Gulab Jamun",
    price: "₹99",
    originalPrice: "₹129",
    image: "/images/gulab-jamun.png",
    rating: 4.7,
    time: "10-15 min",
    isSpicy: false,
    discount: "23% OFF",
    category: "Desserts",
    description: "Soft milk dumplings soaked in rose-flavored syrup",
    isVeg: true,
  },
  {
    id: 15,
    name: "Ice Cream Sundae",
    price: "₹149",
    originalPrice: "₹199",
    image: "/images/ice-cream.png",
    rating: 4.5,
    time: "5-10 min",
    isSpicy: false,
    discount: "25% OFF",
    category: "Desserts",
    description: "Vanilla ice cream with chocolate sauce and nuts",
    isVeg: true,
  },

  // Beverages
  {
    id: 16,
    name: "Mango Lassi",
    price: "₹79",
    originalPrice: "₹99",
    image: "/images/mango-lassi.png",
    rating: 4.6,
    time: "5-10 min",
    isSpicy: false,
    discount: "20% OFF",
    category: "Beverages",
    description: "Refreshing yogurt drink blended with fresh mango",
    isVeg: true,
  },
]

const categories = ["All", "Main Course", "Starters", "Fast Food", "Thali", "Desserts", "Beverages"]

export function EnhancedMenuSection() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")
  const [showVegOnly, setShowVegOnly] = useState(false)
  const [sortBy, setSortBy] = useState("popular")

  const filteredDishes = allDishes
    .filter((dish) => {
      const matchesCategory = selectedCategory === "All" || dish.category === selectedCategory
      const matchesSearch = dish.name.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesVeg = !showVegOnly || dish.isVeg
      return matchesCategory && matchesSearch && matchesVeg
    })
    .sort((a, b) => {
      if (sortBy === "popular") return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0)
      if (sortBy === "rating") return b.rating - a.rating
      if (sortBy === "price")
        return Number.parseInt(a.price.replace("₹", "")) - Number.parseInt(b.price.replace("₹", ""))
      return 0
    })

  const popularDishes = allDishes.filter((dish) => dish.isPopular).slice(0, 3)
  const bestsellerDishes = allDishes.filter((dish) => dish.isBestseller).slice(0, 3)

  return (
    <section id="menu" className="py-20 bg-gradient-to-br from-gray-50 to-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600 mb-4 px-4 py-2">
            🍽️ Our Menu
          </Badge>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">Delicious Food Menu</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our wide variety of dishes, prepared with love and delivered fresh to your doorstep
          </p>
        </div>

        {/* Popular & Bestseller Sections */}
        <div className="mb-16 space-y-12">
          {/* Popular Dishes */}
          <div>
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 p-2 rounded-full">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Popular This Week</h3>
              </div>
              <Badge className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white px-4 py-2">🔥 Trending</Badge>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {popularDishes.map((dish) => (
                <ImprovedFoodCard key={dish.id} dish={dish} />
              ))}
            </div>
          </div>

          {/* Bestseller Dishes */}
          <div>
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-2 rounded-full">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Bestsellers</h3>
              </div>
              <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-4 py-2">⭐ Top Rated</Badge>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {bestsellerDishes.map((dish) => (
                <ImprovedFoodCard key={dish.id} dish={dish} />
              ))}
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="mb-12 space-y-6">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search for dishes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 py-3 border-2 border-gray-200 focus:border-orange-500 rounded-full"
              />
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant={showVegOnly ? "default" : "outline"}
                onClick={() => setShowVegOnly(!showVegOnly)}
                className={
                  showVegOnly
                    ? "bg-green-500 hover:bg-green-600 rounded-full"
                    : "border-green-500 text-green-500 hover:bg-green-500 hover:text-white rounded-full"
                }
              >
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                Veg Only
              </Button>
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="popular">Sort by Popular</option>
                  <option value="rating">Sort by Rating</option>
                  <option value="price">Sort by Price</option>
                </select>
              </div>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={
                  selectedCategory === category
                    ? "bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 rounded-full px-6"
                    : "border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white bg-transparent rounded-full px-6"
                }
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* All Menu Items */}
        <div>
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-gray-900">All Menu Items</h3>
            <div className="text-sm text-gray-600 bg-white px-4 py-2 rounded-full shadow">
              Showing {filteredDishes.length} of {allDishes.length} dishes
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredDishes.map((dish) => (
              <ImprovedFoodCard key={dish.id} dish={dish} />
            ))}
          </div>
        </div>

        {filteredDishes.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg mb-4">No dishes found matching your criteria</div>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setSelectedCategory("All")
                setShowVegOnly(false)
              }}
              className="rounded-full"
            >
              Clear Filters
            </Button>
          </div>
        )}

        {/* Enhanced Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
            <div className="text-3xl font-bold text-orange-500 mb-2">{allDishes.length}+</div>
            <div className="text-gray-600 flex items-center justify-center">
              <Users className="w-4 h-4 mr-1" />
              Menu Items
            </div>
          </div>
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
            <div className="text-3xl font-bold text-green-500 mb-2">{allDishes.filter((d) => d.isVeg).length}+</div>
            <div className="text-gray-600">Veg Options</div>
          </div>
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
            <div className="text-3xl font-bold text-red-500 mb-2">{categories.length - 1}</div>
            <div className="text-gray-600">Categories</div>
          </div>
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
            <div className="text-3xl font-bold text-blue-500 mb-2 flex items-center justify-center">
              <Clock className="w-6 h-6 mr-1" />
              30min
            </div>
            <div className="text-gray-600">Avg Delivery</div>
          </div>
        </div>
      </div>
    </section>
  )
}
