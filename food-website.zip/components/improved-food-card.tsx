"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Star, Heart, Flame, Leaf, ShoppingCart } from "lucide-react"
import Image from "next/image"
import { useCart } from "@/hooks/use-cart"
import { useState } from "react"

interface Dish {
  id: number
  name: string
  price: string
  originalPrice?: string
  image: string
  rating: number
  time: string
  isSpicy: boolean
  discount?: string
  category: string
  description: string
  isVeg: boolean
  isPopular?: boolean
  isBestseller?: boolean
}

interface FoodCardProps {
  dish: Dish
}

export function ImprovedFoodCard({ dish }: FoodCardProps) {
  const { addItem } = useCart()
  const [isLiked, setIsLiked] = useState(false)
  const [isAdding, setIsAdding] = useState(false)

  const handleAddToCart = async () => {
    setIsAdding(true)

    // Add item to cart
    addItem({
      id: dish.id,
      name: dish.name,
      price: dish.price,
      image: dish.image,
      originalPrice: dish.originalPrice,
    })

    // Show success feedback
    setTimeout(() => {
      setIsAdding(false)
    }, 1000)
  }

  // Calculate discount percentage
  const getDiscountPercentage = () => {
    if (!dish.originalPrice) return null
    const original = Number.parseInt(dish.originalPrice.replace("₹", ""))
    const current = Number.parseInt(dish.price.replace("₹", ""))
    return Math.round(((original - current) / original) * 100)
  }

  const discountPercentage = getDiscountPercentage()

  return (
    <Card className="group hover:shadow-2xl transition-all duration-300 border-0 shadow-lg overflow-hidden bg-white relative">
      <div className="relative overflow-hidden">
        <Image
          src={dish.image || "/placeholder.svg"}
          alt={dish.name}
          width={400}
          height={280}
          className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
          onError={(e) => {
            e.currentTarget.src = `/placeholder.svg?height=280&width=400&text=${encodeURIComponent(dish.name)}`
          }}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Top badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {discountPercentage && (
            <div className="relative">
              <div className="bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
                {discountPercentage}% OFF
              </div>
              <div className="absolute -inset-1 bg-gradient-to-r from-red-500 to-pink-500 rounded-full blur opacity-30 animate-pulse"></div>
            </div>
          )}

          {dish.isPopular && (
            <Badge className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:from-orange-600 hover:to-yellow-600 text-xs font-semibold">
              🔥 Popular
            </Badge>
          )}

          {dish.isBestseller && (
            <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 text-xs font-semibold">
              ⭐ Bestseller
            </Badge>
          )}
        </div>

        {/* Veg/Non-veg indicator */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="bg-white/90 hover:bg-white shadow-lg backdrop-blur-sm"
            onClick={() => setIsLiked(!isLiked)}
          >
            <Heart className={`w-4 h-4 ${isLiked ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
          </Button>

          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg ${
              dish.isVeg ? "bg-green-500" : "bg-red-500"
            }`}
          >
            {dish.isVeg ? (
              <Leaf className="w-4 h-4 text-white" />
            ) : (
              <div className="w-3 h-3 bg-white rounded-full"></div>
            )}
          </div>
        </div>

        {/* Spicy indicator */}
        {dish.isSpicy && (
          <div className="absolute bottom-3 left-3">
            <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600 text-xs">
              <Flame className="w-3 h-3 mr-1" />
              Spicy
            </Badge>
          </div>
        )}

        {/* Category */}
        <div className="absolute bottom-3 right-3">
          <Badge variant="secondary" className="bg-black/70 text-white hover:bg-black/70 text-xs backdrop-blur-sm">
            {dish.category}
          </Badge>
        </div>
      </div>

      <CardContent className="p-5">
        <div className="space-y-4">
          {/* Title and Description */}
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-gray-900 line-clamp-1 group-hover:text-orange-500 transition-colors">
              {dish.name}
            </h3>
            <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">{dish.description}</p>
          </div>

          {/* Rating */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1 bg-green-50 px-3 py-1 rounded-full">
              <Star className="w-4 h-4 text-green-600 fill-current" />
              <span className="text-sm font-semibold text-green-600">{dish.rating}</span>
              <span className="text-xs text-gray-500">(150+)</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-500">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">{dish.time}</span>
            </div>
          </div>

          {/* Price and Add Button */}
          <div className="flex items-center justify-between pt-2">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-orange-500">{dish.price}</span>
                {dish.originalPrice && <span className="text-sm text-gray-400 line-through">{dish.originalPrice}</span>}
              </div>
              {discountPercentage && (
                <div className="text-xs text-green-600 font-medium">
                  You save ₹
                  {Number.parseInt(dish.originalPrice?.replace("₹", "") || "0") -
                    Number.parseInt(dish.price.replace("₹", ""))}
                </div>
              )}
            </div>

            <Button
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold px-6 py-2 rounded-full transition-all duration-200 transform hover:scale-105 shadow-lg"
              onClick={handleAddToCart}
              disabled={isAdding}
            >
              {isAdding ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Adding...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add</span>
                </div>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
