"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Star, Heart, Flame, Leaf } from "lucide-react"
import Image from "next/image"
import { useCart } from "@/hooks/use-cart"
import { useState } from "react"

interface Dish {
  id: number
  name: string
  price: string
  originalPrice?: string
  image: string
  rating: number
  time: string
  isSpicy: boolean
  discount?: string
  category: string
  description: string
  isVeg: boolean
}

interface FoodCardProps {
  dish: Dish
}

export function FoodCard({ dish }: FoodCardProps) {
  const { addItem } = useCart()
  const [isLiked, setIsLiked] = useState(false)
  const [isAdding, setIsAdding] = useState(false)

  const handleAddToCart = async () => {
    setIsAdding(true)

    // Add item to cart
    addItem({
      id: dish.id,
      name: dish.name,
      price: dish.price,
      image: dish.image,
      originalPrice: dish.originalPrice,
    })

    // Show success feedback
    setTimeout(() => {
      setIsAdding(false)
    }, 800)
  }

  return (
    <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden bg-white">
      <div className="relative">
        <Image
          src={dish.image || "/placeholder.svg"}
          alt={dish.name}
          width={400}
          height={250}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {dish.discount && (
            <Badge className="bg-red-500 text-white hover:bg-red-500 text-xs font-semibold">{dish.discount}</Badge>
          )}
          <div className="flex gap-1">
            {dish.isVeg ? (
              <Badge className="bg-green-500 text-white hover:bg-green-500 text-xs">
                <Leaf className="w-3 h-3 mr-1" />
                Veg
              </Badge>
            ) : (
              <Badge className="bg-red-600 text-white hover:bg-red-600 text-xs">Non-Veg</Badge>
            )}
          </div>
        </div>

        {/* Heart Button */}
        <div className="absolute top-3 right-3">
          <Button
            variant="ghost"
            size="sm"
            className="bg-white/90 hover:bg-white shadow-md"
            onClick={() => setIsLiked(!isLiked)}
          >
            <Heart className={`w-4 h-4 ${isLiked ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
          </Button>
        </div>

        {/* Spicy Indicator */}
        {dish.isSpicy && (
          <div className="absolute bottom-3 left-3">
            <Badge className="bg-orange-500 text-white hover:bg-orange-500 text-xs">
              <Flame className="w-3 h-3 mr-1" />
              Spicy
            </Badge>
          </div>
        )}

        {/* Category */}
        <div className="absolute bottom-3 right-3">
          <Badge variant="secondary" className="bg-black/70 text-white hover:bg-black/70 text-xs">
            {dish.category}
          </Badge>
        </div>
      </div>

      <CardContent className="p-5">
        <div className="space-y-3">
          {/* Title and Rating */}
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-gray-900 line-clamp-1 group-hover:text-orange-500 transition-colors">
              {dish.name}
            </h3>
            <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">{dish.description}</p>
          </div>

          {/* Price and Rating Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-orange-500">{dish.price}</span>
              {dish.originalPrice && <span className="text-sm text-gray-400 line-through">{dish.originalPrice}</span>}
            </div>
            <div className="flex items-center space-x-1 bg-green-50 px-2 py-1 rounded-full">
              <Star className="w-3 h-3 text-green-600 fill-current" />
              <span className="text-xs font-medium text-green-600">{dish.rating}</span>
            </div>
          </div>

          {/* Time and Add Button */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2 text-gray-500">
              <Clock className="w-4 h-4" />
              <span className="text-sm">{dish.time}</span>
            </div>
            <Button
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-sm px-4 py-2 h-9 transition-all duration-200"
              onClick={handleAddToCart}
              disabled={isAdding}
            >
              {isAdding ? "✓ Added!" : "Add to Cart"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
